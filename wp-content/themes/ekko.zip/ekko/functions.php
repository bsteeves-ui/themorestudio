<?php
/**
 * ekko functions file
 *
 * @package ekko
 * by KeyDesign
 */

update_option( 'keydesign-verify' , 'yes' );

require_once( get_template_directory() . '/core/init.php');

 // -------------------------------------
 // Edit below this line
 // -------------------------------------